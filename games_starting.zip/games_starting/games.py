import random

money = 100

#Write your game of chance functions here






#Call your game of chance functions here
